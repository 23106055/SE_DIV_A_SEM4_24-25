<?php

session_start();
if(!isset($_SESSION['email'])){
    header("Location: ../landing_page/page1.php");
    exit();
}

?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>YouTube Homepage Clone | CodingNepal</title>
        <!-- Linking Unicons For Icons -->
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="notes.css" />
    </head>
    <body class="sidebar-hidden">

        <div class="branding">
            <div><h1 class="aspira-title">ASPIRA</h1></div>
            <div class="navbar">
                <a href="../homepage/homepage.php">Home</a>
                <a href="../homepage/about.php">About Us</a>
                <a href="../Notes/notes.php">Notes</a>
                <a href="../homepage/contact.php">Contact</a>
                <button class="nav-button theme-button">
                    <i class="uil uil-moon"></i>
                </button>
            </div>
            <div class='profile'>
                <i class='fas fa-user-circle' style='font-size:48px;color:red'></i>
                <div id="profileDropdown" class="profile-dropdown">
                    <p>Name : <?= $_SESSION['name']; ?></p>
                    <p>Email : <?= $_SESSION['email']; ?></p>
                    <button onclick="window.location.href='../login_page/logout.php'" class="logout-button">Logout</button>
                </div>
            </div>
        </div>

        <div class="container">
        <!-- Header / Navbar -->
            <!--<header>
                <nav class="navbar">
                    <div class="nav-section nav-left">
                        <button class="nav-button menu-button">
                            <i class="uil uil-bars"></i>
                        </button>
                        <a href="#" class="nav-logo">
                            <img src="images/logo.png" alt="Logo" class="logo-image" />
                            <h2 class="logo-text">CnTube</h2>
                        </a>
                    </div>
                    <div class="nav-section">
                        <button class="nav-button search-back-button" id="search-back-button">
                            <i class="uil uil-arrow-left"></i>
                        </button>
                    </div>
                    <div class="nav-section nav-center">
                        <form action="#" class="search-form">
                            <input type="search" placeholder="Search" class="search-input" required />
                            <button class="nav-button search-button">
                                <i class="uil uil-search"></i>
                            </button>
                        </form>
                        <button class="nav-button mic-button">
                            <i class="uil uil-microphone"></i>
                        </button>
                    </div>
                    <div class="nav-section nav-right">
                        <button class="nav-button search-button" id="search-button">
                            <i class="uil uil-search"></i>
                        </button>
                        <button class="nav-button theme-button">
                            <i class="uil uil-moon"></i>
                        </button>
                        <img src="images/user.jpg" alt="User Image" class="user-image" />
                    </div>
                </nav>
            </header>-->
        <!-- Main Layout -->
        <main class="main-layout">
            <div class="screen-overlay"></div>
            <!-- Sidebar -->
            <!--<aside class="sidebar">
                <div class="nav-section nav-left">
                    <button class="nav-button menu-button">
                        <i class="uil uil-bars"></i>
                    </button>
                    <a href="#" class="nav-logo">
                        <img src="images/logo.png" alt="Logo" class="logo-image" />
                        <h2 class="logo-text">CnTube</h2>
                    </a>
                </div>
                <div class="links-container">
                    <div class="link-section">
                        <a href="#" class="link-item"> <i class="uil uil-estate"></i> Home </a>
                        <a href="#" class="link-item"> <i class="uil uil-video"></i> Shorts </a>
                        <a href="#" class="link-item"> <i class="uil uil-tv-retro"></i> Subscriptions </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">You</h4>
                        <a href="#" class="link-item"> <i class="uil uil-user-square"></i> Your channel </a>
                        <a href="#" class="link-item"> <i class="uil uil-history"></i> History </a>
                        <a href="#" class="link-item"> <i class="uil uil-clock"></i> Watch later </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">Explore</h4>
                        <a href="#" class="link-item"> <i class="uil uil-fire"></i> Trending </a>
                        <a href="#" class="link-item"> <i class="uil uil-music"></i> Music </a>
                        <a href="#" class="link-item"> <i class="uil uil-basketball"></i> Gaming </a>
                        <a href="#" class="link-item"> <i class="uil uil-trophy"></i> Sports </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">More from YouTube</h4>
                        <a href="#" class="link-item"> <i class="uil uil-shield-plus"></i> YouTube Plus </a>
                        <a href="#" class="link-item"> <i class="uil uil-headphones-alt"></i> YouTube Music </a>
                        <a href="#" class="link-item"> <i class="uil uil-airplay"></i> YouTube Kids </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <a href="#" class="link-item"> <i class="uil uil-setting"></i> Settings </a>
                        <a href="#" class="link-item"> <i class="uil uil-file-medical-alt"></i> Report </a>
                        <a href="#" class="link-item"> <i class="uil uil-question-circle"></i> Help </a>
                        <a href="#" class="link-item"> <i class="uil uil-exclamation-triangle"></i> Feedback </a>
                    </div>
                </div>
            </aside>-->
            <div class="content-wrapper">
                <!-- Category List -->
                <!--<div class="category-list">
                    <button class="category-button active">All</button>
                    <button class="category-button">Website</button>
                    <button class="category-button">Music</button>
                    <button class="category-button">Gaming</button>
                    <button class="category-button">Node.js</button>
                    <button class="category-button">JavaScript</button>
                    <button class="category-button">React.js</button>
                    <button class="category-button">TypeScript</button>
                    <button class="category-button">Coding</button>
                    <button class="category-button">Next.js</button>
                    <button class="category-button">Data analysis</button>
                    <button class="category-button">Web design</button>
                    <button class="category-button">HTML</button>
                    <button class="category-button">Tailwind</button>
                    <button class="category-button">CSS</button>
                    <button class="category-button">Express.js</button>
                </div>-->
            <!-- Video List -->
                <div class="video-list">
                    <a href="gk.php" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://media.licdn.com/dms/image/v2/C4D12AQGhqWAorse66Q/article-cover_image-shrink_600_2000/article-cover_image-shrink_600_2000/0/1646652325563?e=2147483647&v=beta&t=77GsCR1X4FHl-ObeSsKHnzAfTRLq_LshYrf2wB6EL-A" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">General Knowledge for UPSC</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="History.pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://rukminim3.flixcart.com/image/850/1000/xif0q/regionalbooks/v/w/f/studyiq-upsc-modern-indian-history-ancient-medieval-history-in-original-imagzw9yjc6uzgup.jpeg?q=90&crop=false" alt="Video Thumbnail" class="thumbnail" />
                                
                        </div>
                        <div class="video-info">
                                <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">History for UPSC</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Geography .pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://i0.wp.com/compass.rauias.com/wp-content/uploads/2024/07/Geography-notes-for-upsc.webp?w=1280&ssl=1" alt="Video Thumbnail" class="thumbnail" />
                                
                        </div>
                        <div class="video-info">
                                <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">Geography for UPSC</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="../Geography_countries/index.php" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://rukminim2.flixcart.com/image/850/1000/poster/r/u/j/posterhouzz-world-political-map-156-pms676-medium-original-imae8hg2eqppxpdh.jpeg?q=90&crop=false" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">Information About Countries</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Defence Information .pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://blog.mentoria.com/wp-content/uploads/2022/09/75bcd19c-d360-4028-8a1b-75652185ecf9_feed_web.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Information About Our Defence Forces</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Physics .pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://i.ytimg.com/vi/ZAqIoDhornk/maxresdefault.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Physics for UPSC</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Chemistry .pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://ramjas.du.ac.in/college/web/dept/chemistry.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Chemistry for UPSC</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Biology .pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://i.ytimg.com/vi/3tisOnOkwzo/maxresdefault.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Biology for UPSC</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Sports.pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://res.cloudinary.com/people-matters/image/upload/q_auto,f_auto/v1545238540/1545238539.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Information About Various Sports</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Superlatives of India.pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://www.karmasandhan.com/wp-content/uploads/My-project-1-6-5.png" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Superlatives of India</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Superlatives of World.pdf#toolbar=0&zoom=150" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeH2d-g-F-OLKgMJ_1EUszh4gDHUEACtRoZg&s" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Superlatives of World</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    
                </div>
            </div>
        </main>
        </div>
        <!-- Linking custom script -->
        <script src="notes.js"></script>
        
    </body>
</html>