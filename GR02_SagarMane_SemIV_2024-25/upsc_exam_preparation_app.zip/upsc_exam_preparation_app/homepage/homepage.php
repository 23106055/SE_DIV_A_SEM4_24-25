<?php

session_start();
if(!isset($_SESSION['email'])){
    header("Location: ../landing_page/page1.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ASPIRA - UPSC Exam Preparation</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" />
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <!-- Full-Screen Welcome Message -->
    <div id="welcomeMessage">
        <h1>Welcome to <span>ASPIRA</span></h1>
    </div>


        <!-- ASPIRA Branding Section -->
    <div class="branding">
        <div><h1 class="aspira-title">ASPIRA</h1></div>
        <div class="navbar">
            <a href="homepage.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="../Notes/notes.php">Notes</a>
            <a href="contact.php">Contact</a>
            <button class="nav-button theme-button">
                <i class="uil uil-moon"></i>
            </button>
        </div>
        <div class='profile'>
            <i class='fas fa-user-circle' style='font-size:48px;color:red'></i>
            <div id="profileDropdown" class="profile-dropdown">
                <p>Name : <?= $_SESSION['name']; ?></p>
                <p>Email : <?= $_SESSION['email']; ?></p>
                <button onclick="window.location.href='../login_page/logout.php'" class="logout-button">Logout</button>
            </div>
        </div>
    </div>
    


    <!-- Main Buttons Section -->
    <section class="buttons">
        <div class="button-container">
            <a  style="text-decoration:none" href="../Notes/notes.php"> <button class="btn notes-btn" ><i class="fas fa-book"></i> Study Notes</button></a>
            <a  style="text-decoration:none" href="../upsc_chatbot/chatbot.php"><button class="btn chatbot-btn"><i class="fas fa-comments"></i> Virtual Assistant</button></a>
            <a  style="text-decoration:none" href="../upsc_quiz/quiz.php"><button class="btn quiz-btn"><i class="fas fa-puzzle-piece"></i> Practice Quizzes</button></a>
        </div>
    </section>

    <!-- Boxes for UPSC Books, Study Tips, Time Management Tips -->
    <section class="boxes">
        <div class="box">
            <i class="fas fa-book-open box-icon"></i>
            <h3>UPSC Books</h3>
            <ul>
                <li>Indian Polity by M. Laxmikanth</li>
                <li>Geography of India by Majid Husain</li>
                <li>Certificate Physical and Human Geography by G.C. Leong</li>
                <li>Indian Economy by Ramesh Singh</li>
            </ul>
        </div>
        <div class="box">
            <i class="fas fa-lightbulb box-icon"></i>
            <h3>Study Tips</h3>
            <ul>
                <li>Make a daily study plan and stick to it.</li>
                <li>Take short breaks to refresh your mind.</li>
                <li>Focus on understanding concepts, not memorizing.</li>
                <li>Make concise notes for revision.</li>
            </ul>
        </div>
        <div class="box">
            <i class="fas fa-clock box-icon"></i>
            <h3>Time Management Tips</h3>
            <ul>
                <li>Prioritize tasks based on importance.</li>
                <li>Set realistic study goals each day.</li>
                <li>Minimize distractions while studying.</li>
                <li>Track your progress regularly.</li>
            </ul>
        </div>
    </section>

                <!-- Quotes Section (One Quote at a Time) -->
    <section class="quotes">
        <div class="quote-container">
            <p class="quote">"Success is the sum of small efforts, repeated day in and day out." – Robert Collier</p>
            <p class="quote">"The future belongs to those who believe in the beauty of their dreams." – Eleanor Roosevelt</p>
            <p class="quote">"The road to success is not easy to navigate, but with hard work, drive, and passion, it's possible to achieve." – Tommy Hilfiger</p>
            <p class="quote">"Don’t watch the clock; do what it does. Keep going." – Sam Levenson</p>
        </div>
    </section>

    <script src="homepage.js"></script>
</body>
</html>
