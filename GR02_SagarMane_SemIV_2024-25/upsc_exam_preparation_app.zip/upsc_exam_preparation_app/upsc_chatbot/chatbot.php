<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot</title>
    <link rel="stylesheet" href="chatbot.css">
</head>
<body>
    <div class="container">
        <h1>Hello Aspirant!!</h1>
        <h2>I am here to help you.</h2>
    </div>
    <div class="chat-container">

    </div>

    <div class="prompt-area">
        <input type="text" id="prompt" placeholder="Ask Something.....">
        <button id="btn"><b>Send</b></button>
    </div>
    <script src="chatbot.js"></script>
</body>
</html>