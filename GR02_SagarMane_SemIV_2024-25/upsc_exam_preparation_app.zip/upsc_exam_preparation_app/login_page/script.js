function showForm(formId){
    document.querySelectorAll(".form-box").forEach(form=>form.classList.remove("active"));
    document.getElementById(formId).classList.add("active");
}

// Add close button functionality - separate from showForm
// Close button functionality
const closeBtn = document.querySelector('.close-btn');
if (closeBtn) {
    closeBtn.onclick = function() {
        window.location.href = '../landing_page/page1.php';
    }
}
