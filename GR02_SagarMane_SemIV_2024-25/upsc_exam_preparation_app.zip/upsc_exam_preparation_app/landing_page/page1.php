<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@4.1.0/fonts/remixicon.css"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="page1.css" />
    <title>UPSC Exam Preparation Site</title>
  </head>
  <body>
    <nav>
    
        <div class="nav__logo">
          <a><span>ASPIRA</span></a>
        </div>
        <div class="nav__header">
          <div class="nav__menu__btn" id="menu-btn">
            <i class="ri-menu-line"></i>
          </div>
        </div>
      <ul class="nav__links" id="nav-links">
        <li><a href="../login_page/index.php">HOME</a></li>
        <li><a href="../login_page/index.php">ABOUT US</a></li>
        <li><a href="../login_page/index.php">CONTACT</a></li>
        <button class="nav-button theme-button">
            <i class="uil uil-moon"></i>
        </button>
      </ul>
      <div class="nav__btns">
        <a href="../login_page/index.php"><button class="btn"><i class="ri-search-line"></i></button></a>
      
      </div>
    </nav>
    <div class="container">
      <div class="container__left">
        <h1>Learn Like Never Before</h1>
        <div class="container__btn">
          <button class="btn"><a href="../login_page/index.php">LOG IN/ REGISTER</a></button>
        </div>
      </div>
      <div class="container__right">
        <div class="images">
          <img src="pic1.png" alt="pic-1" class="pic-1" />
          <img src="pic2.png" alt="pic-2" class="pic-2" />
        </div>
        <div class="content">
          
          <h2><span>ASPIRA:</span> The Path to UPSC Success</h2>
          
          <p>
           Aspira is for those who dream of becoming civil servants. With dedication,
            discipline, and a focused approach, aspiring UPSC students can navigate the vast syllabus and emerge successful.
             Stay motivated, and let your aspirations drive you to reach your goal.
          </p>
        </div>
      </div>
      <div class="location">
        <button class="btn"><span><i class="ri-map-pin-2-fill"></i></span>
        <a href="../login_page/index.php">OUR LOCATION</a></button>
      </div>
      <div class="socials">
        <span>
          <a href="#"><i class="ri-facebook-fill"></i></a>
        </span>
        <span>
          <a href="#"><i class="ri-instagram-line"></i></a>
        </span>
        <span>
          <a href="#"><i class="ri-twitter-fill"></i></a>
        </span>
      </div>
    </div>

    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="page1.js"></script>
    
  </body>
</html>