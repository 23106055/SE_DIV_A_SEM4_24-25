<?php

session_start();
if(!isset($_SESSION['email'])){
    header("Location: ../landing_page/page1.php");
    exit();
}

?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>YouTube Homepage Clone | CodingNepal</title>
        <!-- Linking Unicons For Icons -->
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="notes.css" />
    </head>
    <body class="sidebar-hidden">

        <div class="branding">
            <div><h1 class="aspira-title">ASPIRA</h1></div>
            <div class="navbar">
                <a href="../homepage/homepage.php">Home</a>
                <a href="../homepage/about.php">About Us</a>
                <a href="../Notes/notes.php">Notes</a>
                <a href="../homepage/contact.php">Contact</a>
                <button class="nav-button theme-button">
                    <i class="uil uil-moon"></i>
                </button>
            </div>
            <div class='profile'>
                <i class='fas fa-user-circle' style='font-size:48px;color:red'></i>
                <div id="profileDropdown" class="profile-dropdown">
                    <p>Name : <?= $_SESSION['name']; ?></p>
                    <p>Email : <?= $_SESSION['email']; ?></p>
                    <button onclick="window.location.href='../login_page/logout.php'" class="logout-button">Logout</button>
                </div>
            </div>
        </div>

        <div class="container">
        <!-- Header / Navbar -->
            <!--<header>
                <nav class="navbar">
                    <div class="nav-section nav-left">
                        <button class="nav-button menu-button">
                            <i class="uil uil-bars"></i>
                        </button>
                        <a href="#" class="nav-logo">
                            <img src="images/logo.png" alt="Logo" class="logo-image" />
                            <h2 class="logo-text">CnTube</h2>
                        </a>
                    </div>
                    <div class="nav-section">
                        <button class="nav-button search-back-button" id="search-back-button">
                            <i class="uil uil-arrow-left"></i>
                        </button>
                    </div>
                    <div class="nav-section nav-center">
                        <form action="#" class="search-form">
                            <input type="search" placeholder="Search" class="search-input" required />
                            <button class="nav-button search-button">
                                <i class="uil uil-search"></i>
                            </button>
                        </form>
                        <button class="nav-button mic-button">
                            <i class="uil uil-microphone"></i>
                        </button>
                    </div>
                    <div class="nav-section nav-right">
                        <button class="nav-button search-button" id="search-button">
                            <i class="uil uil-search"></i>
                        </button>
                        <button class="nav-button theme-button">
                            <i class="uil uil-moon"></i>
                        </button>
                        <img src="images/user.jpg" alt="User Image" class="user-image" />
                    </div>
                </nav>
            </header>-->
        <!-- Main Layout -->
        <main class="main-layout">
            <div class="screen-overlay"></div>
            <!-- Sidebar -->
            <!--<aside class="sidebar">
                <div class="nav-section nav-left">
                    <button class="nav-button menu-button">
                        <i class="uil uil-bars"></i>
                    </button>
                    <a href="#" class="nav-logo">
                        <img src="images/logo.png" alt="Logo" class="logo-image" />
                        <h2 class="logo-text">CnTube</h2>
                    </a>
                </div>
                <div class="links-container">
                    <div class="link-section">
                        <a href="#" class="link-item"> <i class="uil uil-estate"></i> Home </a>
                        <a href="#" class="link-item"> <i class="uil uil-video"></i> Shorts </a>
                        <a href="#" class="link-item"> <i class="uil uil-tv-retro"></i> Subscriptions </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">You</h4>
                        <a href="#" class="link-item"> <i class="uil uil-user-square"></i> Your channel </a>
                        <a href="#" class="link-item"> <i class="uil uil-history"></i> History </a>
                        <a href="#" class="link-item"> <i class="uil uil-clock"></i> Watch later </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">Explore</h4>
                        <a href="#" class="link-item"> <i class="uil uil-fire"></i> Trending </a>
                        <a href="#" class="link-item"> <i class="uil uil-music"></i> Music </a>
                        <a href="#" class="link-item"> <i class="uil uil-basketball"></i> Gaming </a>
                        <a href="#" class="link-item"> <i class="uil uil-trophy"></i> Sports </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <h4 class="section-title">More from YouTube</h4>
                        <a href="#" class="link-item"> <i class="uil uil-shield-plus"></i> YouTube Plus </a>
                        <a href="#" class="link-item"> <i class="uil uil-headphones-alt"></i> YouTube Music </a>
                        <a href="#" class="link-item"> <i class="uil uil-airplay"></i> YouTube Kids </a>
                    </div>
                    <div class="section-separator"></div>
                    <div class="link-section">
                        <a href="#" class="link-item"> <i class="uil uil-setting"></i> Settings </a>
                        <a href="#" class="link-item"> <i class="uil uil-file-medical-alt"></i> Report </a>
                        <a href="#" class="link-item"> <i class="uil uil-question-circle"></i> Help </a>
                        <a href="#" class="link-item"> <i class="uil uil-exclamation-triangle"></i> Feedback </a>
                    </div>
                </div>
            </aside>-->
            <div class="content-wrapper">
                <!-- Category List -->
                <!--<div class="category-list">
                    <button class="category-button active">All</button>
                    <button class="category-button">Website</button>
                    <button class="category-button">Music</button>
                    <button class="category-button">Gaming</button>
                    <button class="category-button">Node.js</button>
                    <button class="category-button">JavaScript</button>
                    <button class="category-button">React.js</button>
                    <button class="category-button">TypeScript</button>
                    <button class="category-button">Coding</button>
                    <button class="category-button">Next.js</button>
                    <button class="category-button">Data analysis</button>
                    <button class="category-button">Web design</button>
                    <button class="category-button">HTML</button>
                    <button class="category-button">Tailwind</button>
                    <button class="category-button">CSS</button>
                    <button class="category-button">Express.js</button>
                </div>-->
            <!-- Video List -->
                <div class="video-list">
                    <a href="Festivals of India.pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://www.hranker.com/blog/wp-content/uploads/2021/04/new-year-festival-hranker.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Festivals of India</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="First in Awards .pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgwiwReHhSWMnfh3OnEThb2CrqXRmCnZseBy14klkXobfJ3jnyuI35eLHKdH4f2L1GMxvSI_dIhlL5UY3_g_xrDR3BT4OxvZjwcAxI5udVJkXHvaD817CV9MIq3BVFJIG5oBCYoTxzE4KDa/s650/First-in-india-awards-honors.jpg" alt="Video Thumbnail" class="thumbnail" />
                                
                        </div>
                        <div class="video-info">
                                <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">First in Awards</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="First in History.pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8SPNxcXgs3_1Pp3MivugalqTSKidN0QIt7ZddXn8XqsLpw21VFDSyzuY9ALBhhnf-F84&usqp=CAU" alt="Video Thumbnail" class="thumbnail" />
                                
                        </div>
                        <div class="video-info">
                                <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">First in History</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="First in Women.pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://content.wforwoman.com/wp-content/uploads/2018/01/DT-agL7WkAA_LPq.jpg" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                                <h2 class="title">First in Women</h2>
                                <p class="channel-name">ASPIRA</p>
                                <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Folk Dances.pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://media.geeksforgeeks.org/wp-content/uploads/20230823161037/Indian-Dance-Forms.webp" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Folk Dances</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Instruments and artists .pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://lh3.googleusercontent.com/ci/AL18g_SkCd6SJQP-S8aYQUTXmD93ASJzAoRU-1iKODInGm70ns8Dz9Q5Z_I9kGf2BbtRY_m18KcQWg=s1200" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Instrument and Artists</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    <a href="Art & Culture .pdf#toolbar=0&zoom=80" class="video-card">
                        <div class="thumbnail-container">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT548PyXTD6540_-ctwHCqp0GKCWhgvMOnxQA&s" alt="Video Thumbnail" class="thumbnail" />
                            
                        </div>
                        <div class="video-info">
                            <!-- <img src="https://yt3.googleusercontent.com/DRtVBjk2Noax94hHqr8yCcEjhNUhHRvyzBE3qS9WWilnE1-uQQNVnQd8mdG9h_IvNZCRApZSQw=s176-c-k-c0x00ffffff-no-rj" alt="Channel Logo" class="icon" /> -->
                            <div class="video-details">
                            <h2 class="title">Art and Culture</h2>
                            <p class="channel-name">ASPIRA</p>
                            <!-- <p class="views">27K Views • 4 months ago</p> -->
                            </div>
                        </div>
                    </a>
                    
                    
                </div>
            </div>
        </main>
        </div>
        <!-- Linking custom script -->
        <script src="notes.js"></script>
        
    </body>
</html>