<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="note.css" />
    <title>notes</title>
</head>
<body>
    <header>
        <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    </header>

    <a href="gk.html">
    <button class="custom-btn btn">
        <span>General Knowledge</span>
    </button>
    </a>

    <a href="../Geography_countries/index.php">
        <button class="custom-btn btn">
            <span>Countries</span>
        </button>
    </a>

    <a href="Biology .pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Biology</span>
        </button>
    </a>

    <a href="Chemistry .pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Chemistry</span>
        </button>
    </a>

    <a href="Geography .pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Geography</span>
        </button>
    </a>

    <a href="Defence Information .pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Deffence Information</span>
        </button>
    </a>

    <a href="History.pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>History</span>
        </button>
    </a>

    <a href="Physics .pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Physics</span>
        </button>
    </a>

    <a href="Sports.pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Sports</span>
        </button>
    </a>

    <a href="Superlatives of India.pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Superlatives of India</span>
        </button>
    </a>

    <a href="Superlatives of World.pdf#toolbar=0&zoom=200">
        <button class="custom-btn btn">
            <span>Superlatives of World</span>
        </button>
    </a>

</body>
</html>

