<?php

session_start();
if(!isset($_SESSION['email'])){
    header("Location: ../landing_page/page1.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Responsive Contact Us page</title>
</head>
<body>

    <div class="branding">
        <div><h1 class="aspira-title">ASPIRA</h1></div>
        <div class="navbar">
            <a href="homepage.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="../Notes/notes.php">Notes</a>
            <a href="contact.php">Contact</a>
            <button class="nav-button theme-button">
                <i class="uil uil-moon"></i>
            </button>
        </div>
        <div class='profile'>
            <i class='fas fa-user-circle' style='font-size:48px;color:red'></i>
            <div id="profileDropdown" class="profile-dropdown">
                <p>Name : <?= $_SESSION['name']; ?></p>
                <p>Email : <?= $_SESSION['email']; ?></p>
                <button onclick="window.location.href='../login_page/logout.php'" class="logout-button">Logout</button>
            </div>
        </div>
    </div>

    <section class="contact">
        <div class="container1">
            <h2>Contact Us</h2>
            <div class="contact-wrapper">
                <div class="contact-form">
                    <h3>Send us a message</h3>
                    <form>
                        <div class="form-group">
                            <input type="text" name="name" placeholder="Your Name">
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" placeholder="Your Email">
                        </div>
                        <div class="form-group">
                            <textarea name="message" placeholder="Your Message"></textarea>
                        </div>
                        <button type="submit">Send Message</button>
                    </form>
                </div>
                <div class="contact-info">
                    <h3>Contact Information</h3>
                    <p><i class="fas fa-phone" style='font-size: 35px'></i>+1 123 456 789</p>
                    <p><i class="fas fa-envelope" style='font-size: 35px'></i>info@example.com</p>
                    <p><i class="fas fa-map-marker-alt" style='font-size: 35px'></i>123 Street, City, Country</p>
                </div>
            </div>
        </div>
    </section>
    <script src="homepage.js"></script>
</body>
</html>
