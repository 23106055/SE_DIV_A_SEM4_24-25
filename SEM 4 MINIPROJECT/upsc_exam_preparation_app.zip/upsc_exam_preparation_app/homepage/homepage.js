document.addEventListener("DOMContentLoaded", function () {
    // Hide the welcome message after 3 seconds and show content
    setTimeout(function () {
        document.getElementById('welcomeMessage').style.opacity = '0'; // Fade out welcome message
        document.getElementById('welcomeMessage').style.zIndex = '-1'; // Remove welcome message from view
        document.querySelector('.quotes').style.opacity = '1'; // Show quotes section
        document.querySelector('.branding').style.opacity = '1'; // Show ASPIRA branding
        document.querySelector('.buttons').style.opacity = '1'; // Show buttons section
        document.querySelector('.boxes').style.opacity = '1'; // Show boxes section
    }, 3000);

    // Show quotes one by one with animation
    let quotes = document.querySelectorAll('.quote');
    let currentQuoteIndex = 0;
    
    function showQuote() {
        quotes.forEach((quote, index) => {
            quote.style.display = 'none';
        });
        
        quotes[currentQuoteIndex].style.display = 'block';
        currentQuoteIndex = (currentQuoteIndex + 1) % quotes.length;
    }

    showQuote();
    setInterval(showQuote, 5000);
});

// Profile dropdown functionality
const profileIcon = document.querySelector('.fa-user-circle');
const dropdown = document.getElementById('profileDropdown');

profileIcon.addEventListener('click', function(event) {
    event.stopPropagation();
    dropdown.classList.toggle('show');
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    if (!dropdown.contains(event.target) && !profileIcon.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

// Prevent dropdown from closing when clicking inside it
dropdown.addEventListener('click', function(event) {
    event.stopPropagation();
});

const themeButton = document.querySelector(".navbar .theme-button i");
// Initialize dark mode based on localStorage
if (localStorage.getItem("darkMode") === "enabled") {
    document.body.classList.add("dark-mode");
    themeButton.classList.replace("uil-moon", "uil-sun");
} else {
    themeButton.classList.replace("uil-sun", "uil-moon");
}
// Toggle dark mode when theme button is clicked
themeButton.addEventListener("click", () => {
    const isDarkMode = document.body.classList.toggle("dark-mode");
    localStorage.setItem("darkMode", isDarkMode ? "enabled" : "disabled");
    themeButton.classList.toggle("uil-sun", isDarkMode);
    themeButton.classList.toggle("uil-moon", !isDarkMode);
});